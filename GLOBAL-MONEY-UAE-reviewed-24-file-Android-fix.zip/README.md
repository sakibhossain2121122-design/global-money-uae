# global-money-uae
Global Money UAE - Bangladesh Remittance Platform

## Native Android DEMO

The standalone Kotlin / Compose app is in [`android/`](android/). See [Android build and Bengali APK installation instructions](android/README.md). The Netlify website remains separate.
